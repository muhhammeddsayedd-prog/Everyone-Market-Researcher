# Create & Upload AI-Generated ASMR YouTube Shorts with Seedance, Fal AI, and GPT-4
> **Category**: AI & Chatbots
> **Views**: 24,339
> **Created**: 6/21/2025
## Description


//ASMR AI Workflow 
Who is this for?

Content Creators, YouTube Automation Enthusiasts, and AI Hobbyists looking to autonomously generate and publish unique, satisfying ASMR-style YouTube Shorts without manual effort.

What problem does this solve?

This workflow solves the creative bottleneck and time-consuming nature of daily content creation. It fully automates the entire production pipeline, from brainstorming trendy ideas to publishing a finished video, turning your n8n instance into a 24/7 content factory.

What this workflow does

1. Two-Stage AI Ideation & Planning:
Uses an initial AI agent to brainstorm a short, viral ASMR concept based on current trends.
A second "Planning" AI agent then takes this concept and expands it into a detailed, structured production plan, complete with a viral-optimized caption, hashtags, and descriptions for the environment and sound.

2. Multi-Modal Asset Generation:
Video:* Feeds detailed scene prompts to the *ByteDance Seedance** text-to-video model (via Wavespeed AI) to generate high-quality video clips.
Audio:* Simultaneously calls the *Fal AI** text-to-audio model to create custom, soothing ASMR sound effects that match the video's theme.
Assembly:** Automatically sequences the video clips and sound into a single, cohesive final video file using an FFMPEG API call.

3. Closed-Loop Publishing & Logging:
Logging:** Initially logs the new idea to a Google Sheet with a status of "In Progress".
Publishing:** Automatically uploads the final, assembled video directly to your YouTube channel, setting the title and description from the AI's plan.
Updating:** Finds the original row in the Google Sheet and updates its status to "Done", adding a direct link to the newly published YouTube video.
Notifications:** Sends real-time alerts to Telegram and/or Gmail with the video title and link, confirming the successful publication.

Setup

Credentials:
You will need to create credentials in your n8n instance for the following services:
OpenAI API
Wavespeed AI API (for Seedance)
Fal AI API
Google OAuth Credential (enable YouTube Data API v3 and Google Sheets API in your Google Cloud Project)
Telegram Bot Credential
(Optional) Gmail OAuth Credential

Configuration:
This is an advanced workflow. The initial setup should take approximately 15-20 minutes.
Google Sheet:* Create a Google Sheet with these columns: idea, caption, production_status, youtube_url. Add the *Sheet ID** to the Google Sheets nodes in the workflow.
Node Configuration:** In the Telegram Notification node, enter your own Chat ID. In the Gmail Notification node, update the recipient email address.
Activate:** Once configured, save and set the workflow to "Active" to let it run on its schedule.

How to customize

Creative Direction:* To change the style or theme of the videos (e.g., from kinetic sand to soap cutting), simply edit the systemMessage in the *"2. Enrich Idea into Plan"* and *"Prompts AI Agent"** nodes.

Initial Ideas:* To influence the AI's starting concepts, modify the prompt in the *"1. Generate Trendy Idea"** node.
Video & Sound:* To change the video duration or sound style, adjust the parameters in the *"Create Clips"* and *"Create Sounds"** nodes.
Notifications:* Add or remove notification channels (like Slack or Discord) after the *"Upload to YouTube"** node.

## Workflow Structure
# Create & Upload AI-Generated ASMR YouTube Shorts with Seedance, Fal AI, and GPT-4

## Basic Information

- Node count: 27
- Connection count: 28

## Key Nodes

### Triggers
- Schedule Trigger (`n8n-nodes-base.scheduleTrigger`)

### AI Nodes
- Think (`@n8n/n8n-nodes-langchain.toolThink`)
- OpenAI Chat Model (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)
- Prompts AI Agent (`@n8n/n8n-nodes-langchain.agent`)
- Parser (`@n8n/n8n-nodes-langchain.outputParserStructured`)
- Parser2 (`@n8n/n8n-nodes-langchain.outputParserStructured`)
- OpenAI Chat Model1 (`@n8n/n8n-nodes-langchain.lmChatOpenAi`)
- 1. Generate Trendy Idea (`@n8n/n8n-nodes-langchain.agent`)
- 2. Enrich Idea into Plan (`@n8n/n8n-nodes-langchain.agent`)

## All Nodes

| Node Name | Type | Category |
|-----------|------|----------|
| Unbundle Prompts | `n8n-nodes-base.code` | Transform |
| Create Sounds | `n8n-nodes-base.httpRequest` | Output |
| Get Sounds | `n8n-nodes-base.httpRequest` | Output |
| Wait for Sounds | `n8n-nodes-base.wait` | Other |
| List Elements | `n8n-nodes-base.code` | Transform |
| Sequence Video | `n8n-nodes-base.httpRequest` | Output |
| Get Final Video | `n8n-nodes-base.httpRequest` | Output |
| Wait for Final Video | `n8n-nodes-base.wait` | Other |
| Think | `@n8n/n8n-nodes-langchain.toolThink` | AI |
| OpenAI Chat Model | `@n8n/n8n-nodes-langchain.lmChatOpenAi` | AI |
| Prompts AI Agent | `@n8n/n8n-nodes-langchain.agent` | AI |
| Parser | `@n8n/n8n-nodes-langchain.outputParserStructured` | AI |
| Schedule Trigger | `n8n-nodes-base.scheduleTrigger` | Trigger |
| Parser2 | `@n8n/n8n-nodes-langchain.outputParserStructured` | AI |
| Create Clips | `n8n-nodes-base.httpRequest` | Output |
| Wait for Clips | `n8n-nodes-base.wait` | Other |
| Get Clips | `n8n-nodes-base.httpRequest` | Output |
| Download Final Video | `n8n-nodes-base.httpRequest` | Output |
| Upload to YouTube | `n8n-nodes-base.youTube` | Other |
| Telegram Notification | `n8n-nodes-base.telegram` | Output |
| OpenAI Chat Model1 | `@n8n/n8n-nodes-langchain.lmChatOpenAi` | AI |
| Gmail Notification | `n8n-nodes-base.gmail` | Output |
| 1. Generate Trendy Idea | `@n8n/n8n-nodes-langchain.agent` | AI |
| 2. Enrich Idea into Plan | `@n8n/n8n-nodes-langchain.agent` | AI |
| 3. Log New Idea to Sheet | `n8n-nodes-base.googleSheets` | Input |
| Update Final Video to Sheet | `n8n-nodes-base.googleSheets` | Input |
| Update Sheet with Youtube Link | `n8n-nodes-base.googleSheets` | Input |

## Connections

```
Think --[ai_tool]--> 2. Enrich Idea into Plan
Think --[ai_tool]--> Prompts AI Agent
Parser --[ai_outputParser]--> 2. Enrich Idea into Plan
Parser2 --[ai_outputParser]--> Prompts AI Agent
Get Clips --[main]--> Create Sounds
Get Sounds --[main]--> List Elements
Create Clips --[main]--> Wait for Clips
Create Sounds --[main]--> Wait for Sounds
List Elements --[main]--> Sequence Video
Sequence Video --[main]--> Wait for Final Video
Wait for Clips --[main]--> Get Clips
Get Final Video --[main]--> Update Final Video to Sheet
Wait for Sounds --[main]--> Get Sounds
Prompts AI Agent --[main]--> Unbundle Prompts
Schedule Trigger --[main]--> 1. Generate Trendy Idea
Unbundle Prompts --[main]--> Create Clips
OpenAI Chat Model --[ai_languageModel]--> 2. Enrich Idea into Plan
OpenAI Chat Model --[ai_languageModel]--> Prompts AI Agent
Upload to YouTube --[main]--> Gmail Notification
Upload to YouTube --[main]--> Telegram Notification
Upload to YouTube --[main]--> Update Sheet with Youtube Link
OpenAI Chat Model1 --[ai_languageModel]--> 1. Generate Trendy Idea
Download Final Video --[main]--> Upload to YouTube
Wait for Final Video --[main]--> Get Final Video
1. Generate Trendy Idea --[main]--> 2. Enrich Idea into Plan
2. Enrich Idea into Plan --[main]--> 3. Log New Idea to Sheet
3. Log New Idea to Sheet --[main]--> Prompts AI Agent
Update Final Video to Sheet --[main]--> Download Final Video
```

## Workflow Summary

This workflow is triggered by Schedule Trigger, uses Think, OpenAI Chat Model, Prompts AI Agent, Parser, Parser2, OpenAI Chat Model1, 1. Generate Trendy Idea, 2. Enrich Idea into Plan for AI processing, goes through 2 transformation step(s), finally outputs to Create Sounds, Get Sounds, Sequence Video, Get Final Video, Create Clips, Get Clips, Download Final Video, Telegram Notification, Gmail Notification.
## Author Information
- **Name**: Bilel Aroua
- **Username**: @bilsimaging
- Verified user
## Related Links
- [View this template on n8n.io](https://n8n.io/workflows/5110)
## Complete Workflow JSON
<details>
<summary>Click to expand Workflow JSON</summary>
```json
{
  "id": 5110,
  "meta": {
    "instanceId": "1d871c7857f6a0f6093c24e2cd2fa1fa755b3826859fe85548d66cefd9f0e0ed"
  },
  "name": "Create & Upload AI-Generated ASMR YouTube Shorts with Seedance, Fal AI, and GPT-4",
  "tags": [
    {
      "id": "1",
      "name": "AI"
    },
    {
      "id": "2",
      "name": "YouTube"
    },
    {
      "id": "3",
      "name": "Content Creation"
    }
  ],
  "nodes": [
    {
      "id": "25a59939-f6b6-4fae-8ed0-7808e008331c",
      "name": "Unbundle Prompts",
      "type": "n8n-nodes-base.code",
      "position": [
        3060,
        220
      ],
      "parameters": {
        "jsCode": "function findSceneEntries(obj) {\n  const scenes = [];\n\n  for (const [key, value] of Object.entries(obj)) {\n    if (key.toLowerCase().startsWith(\"scene\") && typeof value === \"string\") {\n      scenes.push(value);\n    } else if (typeof value === \"object\" && value !== null) {\n      scenes.push(...findSceneEntries(value));\n    }\n  }\n\n  return scenes;\n}\n\nlet output = [];\n\ntry {\n  const inputData = items[0].json;\n  const scenes = findSceneEntries(inputData);\n\n  if (scenes.length === 0) {\n    throw new Error(\"No scene keys found at any level.\");\n  }\n\n  output = scenes.map(scene => ({ description: scene }));\n} catch (e) {\n  throw new Error(\"Could not extract scenes properly. Details: \" + e.message);\n}\n\nreturn output;\n"
      },
      "typeVersion": 2
    },
    {
      "id": "c15a3956-bf4f-446e-b14b-1304d5b37f3d",
      "name": "Create Sounds",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        3260,
        440
      ],
      "parameters": {
        "url": "https://queue.fal.run/fal-ai/mmaudio-v2 ",
        "body": "= {\n        \"prompt\": \"ASMR Soothing sound effects. {{ $('Prompts AI Agent').item.json.output.Sound }}\",\n        \"duration\": 10,\n        \"video_url\": \"{{ $json.data.outputs[0] }}\"\n  }\n",
        "method": "POST",
        "options": {
          "batching": {
            "batch": {
              "batchSize": 1,
              "batchInterval": 2000
            }
          }
        },
        "sendBody": true,
        "contentType": "raw",
        "authentication": "genericCredentialType",
        "rawContentType": "application/json",
        "genericAuthType": "httpHeaderAuth"
      },
      "credentials": {},
      "typeVersion": 4.2
    },
    {
      "id": "d277a432-e3b3-4069-837c-6e68def03672",
      "name": "Get Sounds",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        3780,
        440
      ],
      "parameters": {
        "url": "=https://queue.fal.run/fal-ai/mmaudio-v2/requests/{{ $json.request_id }}",
        "options": {},
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth"
      },
      "credentials": {},
      "typeVersion": 4.2
    },
    {
      "id": "2734cc8e-416a-41fd-a20b-40c079889907",
      "name": "Wait for Sounds",
      "type": "n8n-nodes-base.wait",
      "position": [
        3480,
        440
      ],
      "parameters": {
        "amount": 60
      },
      "typeVersion": 1.1
    },
    {
      "id": "70f2ebeb-1ef1-439c-88b5-3c6094dca6a3",
      "name": "List Elements",
      "type": "n8n-nodes-base.code",
      "position": [
        3060,
        640
      ],
      "parameters": {
        "jsCode": "return [\n  {\n    video_urls: items.map(item => item.json.video.url)\n  }\n];"
      },
      "typeVersion": 2
    },
    {
      "id": "8892adcd-e2da-476c-998d-b814b12184e0",
      "name": "Sequence Video",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        3260,
        640
      ],
      "parameters": {
        "url": "https://queue.fal.run/fal-ai/ffmpeg-api/compose",
        "body": "={\n  \"tracks\": [\n    {\n      \"id\": \"1\",\n      \"type\": \"video\",\n      \"keyframes\": [\n        { \"url\": \"{{ $json.video_urls[0] }}\", \"timestamp\": 0, \"duration\": 10 },\n        { \"url\": \"{{ $json.video_urls[1] }}\", \"timestamp\": 10, \"duration\": 10 },\n        { \"url\": \"{{ $json.video_urls[2] }}\", \"timestamp\": 20, \"duration\": 10 }\n      ]\n    }\n  ]\n}",
        "method": "POST",
        "options": {
          "batching": {
            "batch": {
              "batchSize": 1,
              "batchInterval": 2000
            }
          }
        },
        "sendBody": true,
        "contentType": "raw",
        "authentication": "genericCredentialType",
        "rawContentType": "application/json",
        "genericAuthType": "httpHeaderAuth"
      },
      "credentials": {},
      "typeVersion": 4.2
    },
    {
      "id": "9063eb02-8cd4-4b75-87f2-fdd59f56f26c",
      "name": "Get Final Video",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        3780,
        640
      ],
      "parameters": {
        "url": "=https://queue.fal.run/fal-ai/ffmpeg-api/requests/{{ $json.request_id }}",
        "options": {},
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth"
      },
      "credentials": {},
      "typeVersion": 4.2
    },
    {
      "id": "b3c4c19c-2caa-454c-ae56-a6c00117a6d4",
      "name": "Wait for Final Video",
      "type": "n8n-nodes-base.wait",
      "position": [
        3480,
        640
      ],
      "parameters": {
        "amount": 60
      },
      "typeVersion": 1.1
    },
    {
      "id": "7edea676-00ad-4c17-8fd9-54e55e06dbc5",
      "name": "Think",
      "type": "@n8n/n8n-nodes-langchain.toolThink",
      "position": [
        2580,
        520
      ],
      "parameters": {},
      "typeVersion": 1
    },
    {
      "id": "9d61496d-66a5-454f-b60a-6d997a4d75e8",
      "name": "OpenAI Chat Model",
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "position": [
        2220,
        440
      ],
      "parameters": {
        "model": {
          "__rl": true,
          "value": "gpt-4.1"
        }
      },
      "credentials": {
        "openAiApi": {}
      },
      "typeVersion": 1.2
    },
    {
      "id": "da01687e-ad98-42c0-bab5-057882d6709b",
      "name": "Prompts AI Agent",
      "type": "@n8n/n8n-nodes-langchain.agent",
      "position": [
        2720,
        220
      ],
      "parameters": {
        "text": "=Give me 3 video prompts based on the previous \n\nUse the Think tool to review your output",
        "options": {
          "systemMessage": "=Role: You are a prompt-generation AI specializing in satisfying, ASMR-style video prompts for kinetic sand. Your task is to generate a multi-scene video sequence that vividly shows a tool (like a knife, scoop, or press) interacting with kinetic sand in a clean, high-detail setting.\n\nYour writing must follow this style:\n\nSatisfying, tactile realism.\nMacro-level detail with a tight focus on the tool interacting with the sand's unique texture.\nThe tool must always be in motion — slicing, scooping, pressing, or crumbling the sand. Never idle or static.\nCamera terms are allowed (e.g. macro view, top-down shot, slow-motion).\n\nEach scene must contain all of the following, expressed through detailed visual language:\n\n✅ The kinetic sand (from the Idea)\n✅ The environment or surface (from the Environment)\n✅ The texture, structure, and behavior of the sand as it's being manipulated\n✅ A visible tool (knife, scoop, mold) actively interacting with the sand\n\nDescriptions should show:\n\nThe physical makeup of the sand — is it layered with different colors, sparkly, smooth, or matte? Emphasize its granular, yet cohesive structure.\nHow the sand responds to the tool — clean slicing, soft crumbling, perfect imprints, satisfying deformation, or a cascading collapse.\nThe interaction between the tool and the sand — sand grains momentarily sticking to the tool, the smooth surface left behind, the crisp edges of a cut.\nAny ASMR-relevant sensory cues like the satisfying crunch, the soft hiss of falling grains, or the shimmer of glitter, but always shown visually — not narrated.\n\nTone:\n\nSatisfying, mesmerizing, tactile.\nNo poetic metaphors, emotion, or storytelling.\nAvoid fantasy or surreal imagery.\nAll description must feel physically grounded and visually appealing.\n\nLength:\n\nEach scene must be between 1,000 and 2,000 characters.\nNo shallow or repetitive scenes — each must be immersive, descriptive, and specific.\nEach scene should explore a distinct phase of the action, a different camera perspective, or a new behavior of the sand.\n\nInputs:\n\nIdea: \"{{ $json.idea }}\"\nEnvironment: \"{{ $json.environment_prompt }}\"\nSound: \"{{ $json.sound_prompt }}\"\n\nFormat:\n\nIdea: \"...\"\nEnvironment: \"...\"\nSound: \"...\"\n\nScene 1: \"...\"\nScene 2: \"...\"\nScene 3: \"...\"\n(and so on)"
        },
        "promptType": "define",
        "hasOutputParser": true
      },
      "typeVersion": 1.9
    },
    {
      "id": "64abf568-4e09-4e5c-bd12-7475e721a54c",
      "name": "Parser",
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "position": [
        2380,
        440
      ],
      "parameters": {
        "jsonSchemaExample": "[\n  {\n    \"Caption\": \"Diver Removes Nets Off Whale 🐋 #whalerescue #marinelife #oceanrescue #seahelpers #love #nature #instagood #explore #viral #savenature #oceanguardians #cleanoceans\",\n    \"Idea\": \"Diver carefully cuts tangled net from distressed whale in open sea\",\n    \"Environment\": \"Open ocean, sunlight beams through water, diver and whale, cinematic realism\",\n    \"Sound\": \"Primary sound description under 15 words\",\n    \"Status\": \"for production\"\n  }\n]\n"
      },
      "typeVersion": 1.2
    },
    {
      "id": "d8c29c02-f396-4150-aa2c-550d7b123f9e",
      "name": "Schedule Trigger",
      "type": "n8n-nodes-base.scheduleTrigger",
      "position": [
        1500,
        220
      ],
      "parameters": {
        "rule": {
          "interval": [
            {
              "field": "minutes",
              "minutesInterval": 30
            }
          ]
        }
      },
      "typeVersion": 1.2
    },
    {
      "id": "f2e85826-3416-4a1e-8f26-5a8538087174",
      "name": "Parser2",
      "type": "@n8n/n8n-nodes-langchain.outputParserStructured",
      "position": [
        2900,
        440
      ],
      "parameters": {
        "jsonSchemaExample": "{\n  \"Idea\": \"An obsidian rock being sliced with a shimmering knife\",\n  \"Environment\": \"Clean studio table, subtle light reflections\",\n  \"Sound\": \"Crisp slicing, deep grinding, and delicate crumbling\",\n  \"Scene 1\": \"Extreme macro shot: a razor-sharp, polished knife blade presses into the dark, granular surface of an obsidian rock, just beginning to indent.\",\n  \"Scene 2\": \"Close-up: fine, iridescent dust particles erupt from the point of contact as the blade cuts deeper into the obsidian, catching the studio light.\",\n  \"Scene 3\": \"Mid-shot: the knife, held perfectly steady, has formed a shallow, clean groove across the obsidian's shimmering surface, revealing a new, smooth texture.\"\n}"
      },
      "typeVersion": 1.2
    },
    {
      "id": "790aee60-38b8-4939-834c-bd468b0f240b",
      "name": "Create Clips",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        3260,
        220
      ],
      "parameters": {
        "url": "https://api.wavespeed.ai/api/v3/bytedance/seedance-v1-lite-t2v-480p",
        "body": "={\n  \"aspect_ratio\": \"9:16\",\n  \"duration\": 10,\n  \"prompt\": \"VIDEO THEME: {{ $('Prompts AI Agent').item.json.output.Idea }} | WHAT HAPPENS IN THE VIDEO: {{ $json.description }} | WHERE THE VIDEO IS SHOT: {{ $('Prompts AI Agent').item.json.output.Environment }}\"\n}\n",
        "method": "POST",
        "options": {
          "batching": {
            "batch": {
              "batchSize": 1,
              "batchInterval": 3000
            }
          }
        },
        "sendBody": true,
        "contentType": "raw",
        "authentication": "genericCredentialType",
        "rawContentType": "application/json",
        "genericAuthType": "httpHeaderAuth"
      },
      "credentials": {},
      "typeVersion": 4.2
    },
    {
      "id": "ba98805d-7d8b-476e-86b3-94017f79454b",
      "name": "Wait for Clips",
      "type": "n8n-nodes-base.wait",
      "position": [
        3480,
        220
      ],
      "parameters": {
        "amount": 120
      },
      "typeVersion": 1.1
    },
    {
      "id": "7fc24bd4-8740-4633-b15a-868ff3cdacf5",
      "name": "Get Clips",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        3780,
        220
      ],
      "parameters": {
        "url": "=https://api.wavespeed.ai/api/v3/predictions/{{ $json.data.id }}/result",
        "options": {},
        "authentication": "genericCredentialType",
        "genericAuthType": "httpHeaderAuth"
      },
      "credentials": {},
      "typeVersion": 4.2
    },
    {
      "id": "614d8a4b-1319-4c0a-9b52-de284c232a6d",
      "name": "Download Final Video",
      "type": "n8n-nodes-base.httpRequest",
      "position": [
        4120,
        820
      ],
      "parameters": {
        "url": "={{ $('Get Final Video').item.json.video_url }}",
        "options": {
          "response": {
            "response": "file"
          }
        }
      },
      "typeVersion": 4.2
    },
    {
      "id": "f916f4e9-9634-4863-bdb9-b56e3401165e",
      "name": "Upload to YouTube",
      "type": "n8n-nodes-base.youTube",
      "position": [
        4320,
        820
      ],
      "parameters": {
        "title": "=AI ASMR : {{ $('Update Final Video to Sheet').item.json.idea }}",
        "options": {
          "tags": "=asmr, viral, asmrai, n8n, automation",
          "description": "=AI-Generated Video Idea: {{ $('Update Final Video to Sheet').item.json.idea }}\n\nThis video was created automatically using our automated workflow #asmrai #asmr #n8n",
          "privacyStatus": "public",
          "notifySubscribers": true
        },
        "resource": "video",
        "operation": "upload"
      },
      "credentials": {
        "youTubeOAuth2Api": {}
      },
      "typeVersion": 1
    },
    {
      "id": "f9c33085-e6e4-41c9-a463-62cb52c6e71c",
      "name": "Telegram Notification",
      "type": "n8n-nodes-base.telegram",
      "position": [
        4600,
        820
      ],
      "parameters": {
        "text": "=✅ Your new video is ready!  **Title:** {{ $('Update Final Video to Sheet').item.json.idea }}  \nWatch it here: \nhttps://www.youtube.com/watch?v={{ $('Upload to YouTube').item.json.id }}",
        "chatId": "YOUR_CHAT_ID",
        "additionalFields": {
          "parse_mode": "HTML"
        }
      },
      "credentials": {
        "telegramApi": {}
      },
      "typeVersion": 1.2
    },
    {
      "id": "acbdb550-278a-4f0a-a3c2-b3f1e9183dec",
      "name": "OpenAI Chat Model1",
      "type": "@n8n/n8n-nodes-langchain.lmChatOpenAi",
      "position": [
        1800,
        420
      ],
      "parameters": {
        "model": {
          "__rl": true,
          "value": "gpt-4.1"
        }
      },
      "credentials": {
        "openAiApi": {}
      },
      "typeVersion": 1.2
    },
    {
      "id": "708c4602-2d5c-49f1-84a8-3117a83ce2cc",
      "name": "Gmail Notification",
      "type": "n8n-nodes-base.gmail",
      "position": [
        4600,
        1000
      ],
      "parameters": {
        "sendTo": "your-email@gmail.com",
        "message": "=✅ Your new video is ready!  **Title:** {{ $('Update Final Video to Sheet').item.json.idea }}  Watch it here: https://www.youtube.com/watch?v={{ $('Upload to YouTube').item.json.id }}",
        "options": {
          "senderName": "Bilsimaging -n8n Automation"
        },
        "subject": "✅ Your new video is ready!"
      },
      "credentials": {
        "gmailOAuth2": {}
      },
      "typeVersion": 2.1
    },
    {
      "id": "86188a74-2ca4-4e15-a151-f5a2ae927763",
      "name": "1. Generate Trendy Idea",
      "type": "@n8n/n8n-nodes-langchain.agent",
      "position": [
        1800,
        220
      ],
      "parameters": {
        "text": "Generate one short, trendy, and viral ASMR video idea. Describe the core concept in less than 10 words. Do not explain it, just state the idea.",
        "options": {
          "systemMessage": "You are an AI that specializes in identifying viral trends on platforms like TikTok and YouTube Shorts. Your job is to brainstorm a single, simple, and satisfying ASMR video concept. You must only return the idea as a single line of plain text. Do not add any extra words, formatting, or explanation."
        },
        "promptType": "define",
        "hasOutputParser": true
      },
      "typeVersion": 1.9
    },
    {
      "id": "2d8da7d8-c7a0-48b6-b999-59832b543e91",
      "name": "Note: AI Ideation",
      "type": "n8n-nodes-base.stickyNote",
      "position": [
        1520,
        0
      ],
      "parameters": {
        "color": 3,
        "width": 940,
        "height": 180,
        "content": "### Step 1: AI Brainstorms an Idea\nThis workflow starts with a Schedule Trigger. The first AI agent generates a simple, trendy ASMR concept. The second agent expands this into a full production plan (caption, environment, etc.)."
      },
      "typeVersion": 1
    },
    {
      "id": "692c4c92-7d16-482f-8bca-cc951ab772e4",
      "name": "Note: Asset Generation",
      "type": "n8n-nodes-base.stickyNote",
      "position": [
        2560,
        0
      ],
      "parameters": {
        "color": 3,
        "width": 600,
        "height": 180,
        "content": "### Step 2: Scene Generation & Video Creation\nThe plan is used to generate detailed scene descriptions. Then, we call the Wavespeed AI (Seedance) and Fal AI APIs to create the video clips and sound effects in parallel."
      },
      "typeVersion": 1
    },
    {
      "id": "211c2810-58c9-4246-ba27-561c3e57a74c",
      "name": "Note: Final Assembly",
      "type": "n8n-nodes-base.stickyNote",
      "position": [
        3260,
        0
      ],
      "parameters": {
        "color": 3,
        "width": 660,
        "height": 180,
        "content": "### Step 3: Final Assembly\nThe video clips are stitched together."
      },
      "typeVersion": 1
    },
    {
      "id": "c76e5236-b71b-4705-b30c-89d5ae5dd0f5",
      "name": "Note: Distribution",
      "type": "n8n-nodes-base.stickyNote",
      "position": [
        4040,
        0
      ],
      "parameters": {
        "color": 3,
        "width": 960,
        "height": 180,
        "content": "### Step 4: Distribution & Logging\nThe final video is uploaded to YouTube, the Google Sheet is updated, and notifications are sent."
      },
      "typeVersion": 1
    },
    {
      "id": "57e8010f-7184-4d88-84fd-d2b85782a09b",
      "name": "SUBMISSION GUIDE",
      "type": "n8n-nodes-base.stickyNote",
      "position": [
        0,
        0
      ],
      "parameters": {
        "width": 1320,
        "height": 1240,
        "content": "//ASMR AI Workflow By Bilsimaging.com\n### How It Works\n\nThis workflow is a fully autonomous content factory that creates and publishes satisfying ASMR-style YouTube Shorts without any human intervention. It's a powerful example of chaining multiple AI services together to generate unique media.\n\nThe process runs in four main stages:\n\n1.  **AI Ideation:** A schedule trigger kicks off the workflow. The first AI agent brainstorms a simple, trendy ASMR concept. A second agent then enriches this concept into a detailed JSON production plan, including a viral-style caption, environment description, and sound profile.\n\n2.  **Asset Generation:** The workflow generates detailed scene-by-scene prompts. It then calls the ByteDance Seedance API (via Wavespeed) to create the video clips and the Fal AI API to generate corresponding sound effects.\n\n3.  **Final Assembly:** The clips are sequenced into a final video. \n\n4.  **Distribution & Logging:** The final video is downloaded, uploaded to a designated YouTube channel, the original row in a Google Sheet is updated with the new YouTube link and a \"Done\" status, and notifications are sent via Telegram and Gmail.\n\n### Set Up Steps\n\nThis is an advanced workflow that requires several credentials. \n\nYou will need to create credentials for the following services:\n\n*   **OpenAI:** For the AI agents.\n*   **Wavespeed AI:** For the Seedance video model.\n*   **Fal AI:** For sound generation and video sequencing.\n*   **Google OAuth:** For both the Google Sheets and YouTube nodes. You will need to enable the Google Sheets API and YouTube Data API v3 in your Google Cloud project.\n*   **Telegram Bot:** For the final notification.\n*   **Gmail (Optional):** If you want email notifications.\n\nYou will also need to create a **Google Sheet** to log the ideas and final outputs. A template can be easily created with columns for `id`, `idea`, `caption`, `production_status`, `environment_prompt`, `sound_prompt`, `final_output`, and `youtube_url`.\n\n### Features\n\n*   **Fully Autonomous Content Creation:** Runs on a schedule to generate and publish content without any manual input.\n*   **Two-Stage AI Ideation:** Uses a \"creative\" AI and a \"planning\" AI to produce more dynamic and well-structured ideas.\n*   **Multi-Modal AI:** Chains together text-to-text, text-to-video, and text-to-audio models in a single, cohesive flow.\n*   **Closed-Loop System:** Logs the initial idea to a Google Sheet and updates the *same row* with the final links and status, creating a perfect production log.\n*   **Spreadsheet as a CMS:** Manage your entire content pipeline from a simple Google Sheet.\n*   **Real-time Notifications:** Get immediate alerts on Telegram or Gmail as soon as a new video is live.\n\n### Pro-Tips & How to Handle APIs\n\n*   **API Rate Limits:** If you run the workflow very frequently, some APIs might temporarily block you. To avoid this, you can adjust the **Schedule Trigger** to run less often (e.g., every 30 minutes instead of every 10). For more advanced control, you can add a `batchInterval` in the settings of the HTTP Request nodes.\n\n\n*   **Cost Management:** Remember that AI API calls cost money. It is highly recommended to set up **budget alerts** in your OpenAI, Fal AI, and Wavespeed AI account dashboards to avoid any surprise bills.\n\n*   **Customization:** The creative core of this workflow is in the **Prompts AI Agent** and **Enrich Idea into Plan** nodes. To change the style, tone, or type of videos created, simply edit the `systemMessage` in the options of these nodes.\n\nFor any help or tips on handling the APIs, don't hesitate to contact me at **bilsimaging@gmail.com**."
      },
      "typeVersion": 1
    },
    {
      "id": "62e10519-d31e-4012-8dcf-7e2e82ab35cd",
      "name": "2. Enrich Idea into Plan",
      "type": "@n8n/n8n-nodes-langchain.agent",
      "position": [
        2200,
        220
      ],
      "parameters": {
        "text": "=Take the following trendy ASMR idea and expand it into a full production plan using your required JSON format. Use the examples below for inspiration on how to format the \"Idea\" field.\n\nThe short ASMR idea is:\n[[\n{{ $json.output }}\n]]\n\nHave your final expanded \"Idea\" field be in this format: \"(color/style) (object) being (action)\". \nExamples for your inspiration: layered rainbow kinetic sand being sliced, sparkly purple soap being scooped, neon green slime being pressed.\n\nUse the Think tool to review your output.",
        "options": {
          "systemMessage": "=**Role**: You are an AI designed to generate 1 immersive, satisfying idea based on a user-provided topic. Your output must be formatted as a JSON array (single line) and follow all the rules below exactly.\n\n***\nRULES:\n\nOnly return 1 idea at a time.\n\nThe user will provide a key topic (e.g. \"kinetic sand slicing,\" \"satisfying sand scooping,\" \"ASMR sand sounds\").\n\nThe Idea must:\n\nBe under 13 words.\n\nDescribe an interesting and viral-worthy moment, action, or event related to the provided topic.\n\nThe Caption must be:\n\nShort, punchy, and viral-friendly.\n\nInclude one relevant emoji.\n\nInclude exactly 12 hashtags in this order:\n** 4 topic-relevant hashtags\n** 4 all-time most popular hashtags\n** 4 currently trending hashtags\n\nAll hashtags must be lowercase.\n\nSet Status to \"for production\" (always).\n\nThe Environment must:\n\nBe under 20 words.\n\nMatch the action in the Idea exactly.\n\nClearly describe:\n\nWhere the event is happening (e.g. minimalist white surface, clean studio table)\nKey visuals or background details (e.g. bright lighting, subtle glitter)\nStyle of scene (e.g. macro close-up, cinematic slow-motion)\n\nThe Sound must:\n\nBe under 15 words.\n\nDescribe the primary sound that makes sense to happen in the video. This will be fed to a sound model later on.\n\n\n***\nOUTPUT FORMAT (single-line JSON array):\n\n[\n  {\n    \"Caption\": \"That crunch! 🤤 #kineticsand #satisfyingvideos #asmrsand #sand #oddlysatisfying #viral #fyp #explore #trending #tiktok #diy #crafts\",\n    \"Idea\": \"Slicing through a block of layered rainbow kinetic sand\",\n    \"Environment\": \"Macro close-up on a clean, bright white surface, cinematic slow-motion\",\n    \"Sound\": \"Crisp, crunchy slicing sounds with a soft, gentle hiss\",\n    \"Status\": \"for production\"\n  }\n]"
        },
        "promptType": "define",
        "hasOutputParser": true
      },
      "typeVersion": 1.9
    },
    {
      "id": "06ccc97f-aa87-4c64-860b-0da4739d3de5",
      "name": "3. Log New Idea to Sheet",
      "type": "n8n-nodes-base.googleSheets",
      "position": [
        2560,
        220
      ],
      "parameters": {
        "columns": {
          "value": {
            "idea": "={{ $json.output[0].Idea }}",
            "caption": "={{ $json.output[0].Caption }}",
            "production": "In Progress",
            "sound_prompt": "={{ $json.output[0].Sound }}",
            "environment_prompt": "={{ $json.output[0].Environment }}"
          },
          "mappingMode": "defineBelow"
        },
        "options": {},
        "operation": "append",
        "sheetName": {
          "__rl": true,
          "value": "YOUR_SHEET_NAME"
        },
        "documentId": {
          "__rl": true,
          "value": "YOUR_GOOGLE_SHEET_ID"
        }
      },
      "credentials": {
        "googleSheetsOAuth2Api": {}
      },
      "typeVersion": 4.5
    },
    {
      "id": "58b1f682-2752-4995-b05e-7598353d7a61",
      "name": "Update Final Video to Sheet",
      "type": "n8n-nodes-base.googleSheets",
      "position": [
        4120,
        640
      ],
      "parameters": {
        "key": "idea",
        "value": "={{ $('Update Final Video to Sheet').item.json.idea }}",
        "columns": {
          "value": {
            "production": "Done",
            "youtube_url": "=",
            "final_output": "={{ $json.video_url }}"
          },
          "mappingMode": "defineBelow"
        },
        "operation": "update",
        "sheetName": {
          "__rl": true,
          "value": "YOUR_SHEET_NAME"
        },
        "documentId": {
          "__rl": true,
          "value": "YOUR_GOOGLE_SHEET_ID"
        }
      },
      "credentials": {
        "googleSheetsOAuth2Api": {}
      },
      "typeVersion": 4.5
    },
    {
      "id": "fbf64920-6e9c-4dfa-b75a-bbf022ea597b",
      "name": "Update Sheet with Youtube Link",
      "type": "n8n-nodes-base.googleSheets",
      "position": [
        4600,
        640
      ],
      "parameters": {
        "key": "idea",
        "value": "={{ $('Update Final Video to Sheet').item.json.idea }}",
        "columns": {
          "value": {
            "youtube_url": "=https://www.youtube.com/watch?v={{ $('Upload to YouTube').item.json.id }}"
          },
          "mappingMode": "defineBelow"
        },
        "operation": "update",
        "sheetName": {
          "__rl": true,
          "value": "YOUR_SHEET_NAME"
        },
        "documentId": {
          "__rl": true,
          "value": "YOUR_GOOGLE_SHEET_ID"
        }
      },
      "credentials": {
        "googleSheetsOAuth2Api": {}
      },
      "typeVersion": 4.5
    }
  ],
  "active": false,
  "pinData": {},
  "settings": {
    "executionOrder": "v1"
  },
  "versionId": "final_submission_v1",
  "connections": {
    "Think": {
      "ai_tool": [
        [
          {
            "node": "2. Enrich Idea into Plan",
            "type": "ai_tool",
            "index": 0
          },
          {
            "node": "Prompts AI Agent",
            "type": "ai_tool",
            "index": 0
          }
        ]
      ]
    },
    "Parser": {
      "ai_outputParser": [
        [
          {
            "node": "2. Enrich Idea into Plan",
            "type": "ai_outputParser",
            "index": 0
          }
        ]
      ]
    },
    "Parser2": {
      "ai_outputParser": [
        [
          {
            "node": "Prompts AI Agent",
            "type": "ai_outputParser",
            "index": 0
          }
        ]
      ]
    },
    "Get Clips": {
      "main": [
        [
          {
            "node": "Create Sounds",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Sounds": {
      "main": [
        [
          {
            "node": "List Elements",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Create Clips": {
      "main": [
        [
          {
            "node": "Wait for Clips",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Create Sounds": {
      "main": [
        [
          {
            "node": "Wait for Sounds",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "List Elements": {
      "main": [
        [
          {
            "node": "Sequence Video",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Sequence Video": {
      "main": [
        [
          {
            "node": "Wait for Final Video",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Wait for Clips": {
      "main": [
        [
          {
            "node": "Get Clips",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Get Final Video": {
      "main": [
        [
          {
            "node": "Update Final Video to Sheet",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Wait for Sounds": {
      "main": [
        [
          {
            "node": "Get Sounds",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Prompts AI Agent": {
      "main": [
        [
          {
            "node": "Unbundle Prompts",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Schedule Trigger": {
      "main": [
        [
          {
            "node": "1. Generate Trendy Idea",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Unbundle Prompts": {
      "main": [
        [
          {
            "node": "Create Clips",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "OpenAI Chat Model": {
      "ai_languageModel": [
        [
          {
            "node": "2. Enrich Idea into Plan",
            "type": "ai_languageModel",
            "index": 0
          },
          {
            "node": "Prompts AI Agent",
            "type": "ai_languageModel",
            "index": 0
          }
        ]
      ]
    },
    "Upload to YouTube": {
      "main": [
        [
          {
            "node": "Gmail Notification",
            "type": "main",
            "index": 0
          },
          {
            "node": "Telegram Notification",
            "type": "main",
            "index": 0
          },
          {
            "node": "Update Sheet with Youtube Link",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "OpenAI Chat Model1": {
      "ai_languageModel": [
        [
          {
            "node": "1. Generate Trendy Idea",
            "type": "ai_languageModel",
            "index": 0
          }
        ]
      ]
    },
    "Download Final Video": {
      "main": [
        [
          {
            "node": "Upload to YouTube",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Wait for Final Video": {
      "main": [
        [
          {
            "node": "Get Final Video",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "1. Generate Trendy Idea": {
      "main": [
        [
          {
            "node": "2. Enrich Idea into Plan",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "2. Enrich Idea into Plan": {
      "main": [
        [
          {
            "node": "3. Log New Idea to Sheet",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "3. Log New Idea to Sheet": {
      "main": [
        [
          {
            "node": "Prompts AI Agent",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Update Final Video to Sheet": {
      "main": [
        [
          {
            "node": "Download Final Video",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}
```
</details>